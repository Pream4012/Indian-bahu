
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

export default function HousewifeHeroPortal() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [adWatched, setAdWatched] = useState(false);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleAdWatch = () => {
    setTimeout(() => setAdWatched(true), 30000);
  };

  return (
    <div className="min-h-screen bg-pink-50 text-center p-4">
      <div className="bg-pink-200 p-4 rounded-2xl shadow-md mb-6">
        <h1 className="text-3xl font-bold text-pink-800">Digital Bahu – Ghar Ki Rani, Ab Digital Duniya Ki Maharani</h1>
        <p className="text-lg text-pink-700 mt-2">Apna video banao, YouTube pe chhayo, aur jeeto ₹5000 tak ka reward!</p>
      </div>

      <div className="flex justify-center gap-4 mb-6">
        <button className="bg-green-500 text-white px-4 py-2 rounded">Participate via WhatsApp</button>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">Participate via Telegram</button>
      </div>

      {!loggedIn && (
        <div className="max-w-md mx-auto mb-6 bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">Login / Register</h2>
          <input placeholder="Enter your mobile or email" className="w-full p-2 border rounded mb-2" />
          <button onClick={handleLogin} className="bg-pink-500 text-white px-4 py-2 rounded w-full">Login</button>
        </div>
      )}

      {loggedIn && !adWatched && (
        <div className="bg-yellow-100 p-4 rounded shadow-md mb-6">
          <p className="text-lg font-medium">Please watch this 30 second ad to unlock videos:</p>
          <button className="mt-2 bg-yellow-500 px-4 py-2 rounded text-white" onClick={handleAdWatch}>Watch Ad</button>
        </div>
      )}

      {loggedIn && adWatched && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="bg-white p-4 rounded shadow">
              <h3 className="font-semibold">Video {i + 1}</h3>
              <a
                href={`https://youtube.com/video${i}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 underline"
              >
                Watch on YouTube
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
